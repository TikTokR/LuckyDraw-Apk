package com.luckydraw.app;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

public class InvestmentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investment);
    }

    public void invest(View view) {
        Toast.makeText(this, "Investment Submitted for Verification", Toast.LENGTH_LONG).show();
    }
}
